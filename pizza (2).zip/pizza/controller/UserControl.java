package com.cg.pos.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.cg.pos.entity.PizzaDetailsDTO;
import com.cg.pos.entity.StoreDetailsDTO;
import com.cg.pos.exceptions.PizzaException;
import com.cg.pos.service.PizzaService;
/*
 * @Controller
 */
@RestController
@RequestMapping("/pizzaDatas")
public class UserControl {

	@Autowired
	private PizzaService service;

	public void setService(PizzaService service) {
		this.service = service;
	}

	/*
	 * Addition of pizza to database
	 */
	@RequestMapping(value = "/add/{storeId}", method = RequestMethod.POST, consumes = "application/json")

	public String addPizzaDetails(@RequestBody PizzaDetailsDTO pizzaDetailsDTO , @PathVariable("storeId") int storeId) {
		String result = "";
		StoreDetailsDTO storeDetailsDTO= new StoreDetailsDTO();
		storeDetailsDTO.setId(storeId);
		try {
			System.out.println(pizzaDetailsDTO);
			result = service.add(pizzaDetailsDTO,storeDetailsDTO);
		} catch (PizzaException e) {
			e.printStackTrace();
		}
		return result;
	}

	/*
	 * get list of all pizza
	 */
	@RequestMapping(value = "/getPizzaDetails", method = RequestMethod.GET, produces = "application/json")
	public List<PizzaDetailsDTO> viewPizza() {
		return service.viewPizza();

	}

	/*
	 * get list of all pizza by id
	 */
	@RequestMapping(value = "/{id}", method = RequestMethod.GET, produces = "application/json")
	public PizzaDetailsDTO getPizzaById(@PathVariable("id") Integer pizzaId) {
		System.out.println("abc");
		PizzaDetailsDTO pizzaDetailsDTO = null;
		try {
			pizzaDetailsDTO = service.retrive(pizzaId);
		} catch (PizzaException e) {
			
			e.printStackTrace();
		}
		return pizzaDetailsDTO;

	}
	

}
