package com.cg.pos.service;

import java.util.ArrayList;

import com.cg.pos.entity.StoreDetailsDTO;

import com.cg.pos.exceptions.PizzaException;

public interface StoreService {
	public ArrayList<StoreDetailsDTO> addStoreDetails(StoreDetailsDTO storeDetailEntity)
			throws PizzaException;

	public String deleteStoreDetails(String storeName);

	public String viewStoreDetails(String storeName);

	public String ModifyStoreName(int storeId, String storeNmae) throws PizzaException;

	public String ModifyStoreContact(int storeId, String storeContact) throws PizzaException;

	public String ModifyStoreAddress(int storeId, String storeAddress) throws PizzaException;

	public String ModifyOwnerName(int storeId, String ownerName) throws PizzaException;

}
