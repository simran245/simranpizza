package com.cg.pos.utility;

import com.cg.pos.exceptions.PizzaException;

/**
 * @validating all the given input from Admin
 */
public class PizzaDetailsValidation {
	/**
	 * 
	 * @param pizzaDetN
	 * @return boolean
	 * @throws PizzaException
	 */
	public boolean isValidPizzaName(String pizzaDetN) throws PizzaException {
		if (pizzaDetN.trim().length() == 0 || (!pizzaDetN.matches("^[a-zA-Z]*$"))) {
			throw new PizzaException(ExceptionMessages.PIZZANAME);
		}

		return true;
	}

	/**
	 * 
	 * @param pizzaDetAd
	 * @return boolean
	 * @throws PizzaException
	 */
	public boolean isValidPizzaAdOns(String pizzaDetAd) throws PizzaException {

		if ((pizzaDetAd.trim().length() == 0 || (!pizzaDetAd.matches("^[a-zA-Z]*$"))))
			throw new PizzaException(ExceptionMessages.ADDONS);
		return true;
	}

	/**
	 * 
	 * @param pizzaDetC
	 * @return boolean
	 * @throws PizzaException
	 */
	public boolean isValidPizzaCost(String pizzaDetC) throws PizzaException {
		if (pizzaDetC.trim().length() == 0 || !(pizzaDetC.matches("[0-9.]{1,5}"))) {
			throw new PizzaException(ExceptionMessages. COST);
		}
		return true;
	}

	/*
	 * @param pizzaDetC
	 * 
	 * @return boolean
	 * 
	 * @throws PizzaException
	 */
	public boolean isValidPizzaId(String pizzaId) throws PizzaException {

		if (pizzaId.trim().length() == 0 || (!pizzaId.matches("[1-9][0-9][0-9]")))

			throw new PizzaException(ExceptionMessages.PIZZAID);

		return true;
	}

	/**
	 * 
	 * @param pizzaDetQ
	 * @return boolean
	 * @throws PizzaException
	 */
	public boolean isValidPizzaQuantity(String pizzaDetQ) throws PizzaException {
		if (pizzaDetQ.trim().length() == 0 || (!pizzaDetQ.matches("[1-9]")))
			throw new PizzaException(ExceptionMessages.QUANTITY);

		return true;
	}

	/**
	 * 
	 * @param storeName
	 * @return boolean
	 * @throws PizzaException
	 */
	public boolean isValidStoreName(String storeName) throws PizzaException {
		if (storeName.trim().length() == 0 || (!storeName.matches("^[a-zA-Z]*$")))
			throw new PizzaException(ExceptionMessages.STOREID);
		return true;
	}

	/*
	 * @param pizza
	 * @return boolean
	 * @throws PizzaException
	 *
	 */
	public boolean isValidStoreId(String tempStoreId) throws PizzaException {
		if (tempStoreId.trim().length() == 0 || (!tempStoreId.matches("[1-9][0-9][0-9][0-9][0-9]")))
			throw new PizzaException(ExceptionMessages.STORENAME);

		return true;
	}
}
