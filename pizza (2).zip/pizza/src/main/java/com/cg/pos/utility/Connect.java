package com.cg.pos.utility;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
/*
 * Connection to be established
 */
public class Connect {

	private static EntityManagerFactory entityManagerFactory;

	public static EntityManagerFactory getEntityManagerFactory() {
	if (entityManagerFactory==null) {
		entityManagerFactory=Persistence.createEntityManagerFactory("qwe");
	}
		return entityManagerFactory;
	}

	public static void shutDown() {
		if (entityManagerFactory!=null) {
		entityManagerFactory.close();
			
		}
	}

	}


