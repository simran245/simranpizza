package com.cg.pos.exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@ControllerAdvice
@RestController
public class PizzaExceptionHandler extends ResponseEntityExceptionHandler {

	@ExceptionHandler(PizzaException.class)
	public ResponseEntity<ErrorDetailsPattern> errorHandle(PizzaException ex,WebRequest request){
		System.out.println("pizzaexception");
		ErrorDetailsPattern details= new ErrorDetailsPattern(ex.getMessage(),request.getDescription(false));
		return new ResponseEntity<>(details,HttpStatus.BAD_REQUEST);
		
	}

}
