package com.cg.pos.service;

import java.util.ArrayList;

import com.cg.pos.entity.PizzaDetailsDTO;

public interface CartService {
	public ArrayList<PizzaDetailsDTO> addItemToCart(int pizzaSelect);
	public ArrayList<PizzaDetailsDTO> removeItemFromCart();
	public void confirmOrder(); 
}
