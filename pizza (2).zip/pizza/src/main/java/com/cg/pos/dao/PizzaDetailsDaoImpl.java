package com.cg.pos.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;
import org.springframework.stereotype.Repository;
import com.cg.pos.entity.PizzaDetailsDTO;
import com.cg.pos.entity.StoreDetailsDTO;
import com.cg.pos.exceptions.PizzaException;

/*
 * @author Simran
 * implementation class for data access 
 */
@Repository
@Transactional
public class PizzaDetailsDaoImpl implements PizzaDetailsDao {
	/*
	 * add pizza to store
	 *
	 */
	@PersistenceContext
	private EntityManager entityManager;   

	public int addPizzaDb(PizzaDetailsDTO pizzaDetailsDTO, StoreDetailsDTO storeDetailsDTO)
			throws PizzaException {
		int result=0;
		storeDetailsDTO= entityManager.find(StoreDetailsDTO.class, storeDetailsDTO.getStoreId());
		if(storeDetailsDTO!=null) {
		pizzaDetailsDTO.setStore(storeDetailsDTO); 
		
		entityManager.persist(pizzaDetailsDTO);
		result=1;
		}
		return result;

	}

	/*
	 * view list by id
	 */
	@Override
	public PizzaDetailsDTO getPizzaDetails(int pizzaId) throws PizzaException {
		PizzaDetailsDTO pizzaDetailsDTO = entityManager.find(PizzaDetailsDTO.class, pizzaId);
		return pizzaDetailsDTO;
	}

	/*
	 * view all the pizza details
	 */
	@Override
	public List<PizzaDetailsDTO> getPizzaList() throws PizzaException {
		TypedQuery<PizzaDetailsDTO> pizza = entityManager.createQuery("select p from PizzaDetailsDTO p",
				PizzaDetailsDTO.class);
		//ArrayList<PizzaDetailsDTO> pizza1 = new ArrayList<PizzaDetailsDTO>();
		List<PizzaDetailsDTO> pizza1 =  pizza.getResultList();
		return pizza1;
	}

	//@Override
//	public PizzaDetailsDTO getStoreList(Integer storeId) throws PizzaException {
//		TypedQuery<PizzaDetailsDTO> pizza=entityManager.createQuery("select storeid from store innerjoin pizza on store(storeid==pizza.storeid having...)",PizzaDetailsDTO.class);
//		ArrayList<PizzaDetailsDTO> pizza2=new ArrayList<PizzaDetailsDTO>();
//		pizza2=(ArrayList<PizzaDetailsDTO>) pizza.getResultList();
//		//return pizza2;
//		return null;
//	}
}
