package com.cg.pos.dao;

import java.util.List;

import com.cg.pos.entity.PizzaDetailsDTO;
import com.cg.pos.entity.StoreDetailsDTO;
import com.cg.pos.exceptions.PizzaException;

/*
 * @author Simran
 * interface to do operations
 */
public interface PizzaDetailsDao {
	int addPizzaDb(PizzaDetailsDTO pizzaDetailsDTO,StoreDetailsDTO storeDetailsDTO) throws PizzaException;

	PizzaDetailsDTO getPizzaDetails(int pizzaId) throws PizzaException;

	List<PizzaDetailsDTO> getPizzaList() throws PizzaException;

//	PizzaDetailsDTO getStoreList(Integer storeId);

}
