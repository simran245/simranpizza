package com.cg.pos.service;

import java.util.ArrayList;
import java.util.List;

import com.cg.pos.entity.PizzaDetailsDTO;
import com.cg.pos.entity.StoreDetailsDTO;
import com.cg.pos.exceptions.PizzaException;



/**
 * 
 * @author Simran service class
 */
public interface PizzaService {
	int add(PizzaDetailsDTO pizzaDetailsDTO, StoreDetailsDTO storeDetailsDTO) throws PizzaException;

	ArrayList<PizzaDetailsDTO> modify(PizzaDetailsDTO pizzaDetails);

	ArrayList<PizzaDetailsDTO> delete(PizzaDetailsDTO pizzaDetails);

	PizzaDetailsDTO retrive(Integer pizzaId) throws PizzaException;

	List<PizzaDetailsDTO> viewPizza() throws PizzaException;

//	PizzaDetailsDTO getStoreList(Integer storeId);



}
