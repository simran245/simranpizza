package com.cg.pos.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.pos.dao.PizzaDetailsDao;
import com.cg.pos.entity.PizzaDetailsDTO;
import com.cg.pos.entity.StoreDetailsDTO;
import com.cg.pos.exceptions.PizzaException;
import com.cg.pos.service.PizzaService;
import com.cg.pos.utility.ExceptionMessages;
import com.cg.pos.utility.PizzaDetailsValidation;

/**
 * 
 * @author Simran
 * @service having addition of pizza to store and view pizza details in stores
 */
@Service
public class PizzaServiceImpl extends PizzaDetailsValidation implements PizzaService {
	@Autowired
	PizzaDetailsDao pizzaDetailsDao;

	/**
	 * @throws PizzaException
	 * @addition of PizzaDetails
	 *
	 */
	public int add(PizzaDetailsDTO pizzaDetailsDTO,StoreDetailsDTO storeDetailsDTO) throws PizzaException {
		int pizzaDetailsDTO1;
		pizzaDetailsDTO1 = pizzaDetailsDao.addPizzaDb(pizzaDetailsDTO,storeDetailsDTO);
//		if (pizzaDetailsDTO != null)
			return pizzaDetailsDTO1 ;
			
	}
	/**
	 * @throws PizzaException
	 * @view of PizzaDetails
	 *
	 */
	@Override
	public PizzaDetailsDTO retrive(Integer pizzaId) throws PizzaException {
		PizzaDetailsDTO pizzaDetailsDTO = pizzaDetailsDao.getPizzaDetails(pizzaId);
		if (pizzaDetailsDTO!=null) {
			return pizzaDetailsDTO;
		}
		else
			throw new PizzaException(ExceptionMessages.NOTEXIST);
	}
	/**
	 * @throws PizzaException
	 * @view of PizzaDetails
	 *
	 */
	@Override
	public List<PizzaDetailsDTO> viewPizza() throws PizzaException {
		List<PizzaDetailsDTO>pizzaList=null;
		//return pizzaDetailsDao.getPizzaList();
//		ArrayList<PizzaDetailsDTO> pizzList = null;
		pizzaList = (pizzaDetailsDao.getPizzaList());
		if (pizzaList==null) {
			throw new PizzaException(ExceptionMessages.NOTEXIST);
		}
//		return pizzList;
		return pizzaList;
		
	}
//	@Override
//	public PizzaDetailsDTO getStoreList(Integer storeId) throws PizzaException{
//		PizzaDetailsDTO pizzaDetailsDTO=pizzaDetailsDao.getStoreList(storeId);
//		if (pizzaDetailsDTO!=null) {
//			return pizzaDetailsDTO;
//			
//		}else
//			throw new PizzaException(ExceptionMessages.NOTEXIST);
//
//	}

	public ArrayList<PizzaDetailsDTO> modify(PizzaDetailsDTO pizzaDetails) {
		return null;
	}

	public ArrayList<PizzaDetailsDTO> delete(PizzaDetailsDTO pizzaDetails) {
		return null;
	}


}