package com.cg.pos.exceptions;
/*
 * exception messages for exceptions
 */
public class ExceptionMessages {

	public static final String PIZZANAME = "please enter correct pizza name";
	public static final String ADDONS = "please enter correct Addons";
	public static final String STOREID = "please enter correct store id";
	public static final String PIZZAID = "Please enter correct pizza id";
	public static final String COST = "Please enter correct pizza cost";
	public static final String QUANTITY = "Please enter correct pizza quantity";
	public static final String NOTEXIST = "Storeid does not exist please enter existing storeid";
	public static final String VALIDID = "Enter valid Store id or pizza ID is already existing";
	public static final String NOTAVIALABLE = "SORRY :( No Pizza is available in store";
	public static final String STORENAME ="please enter correct store name";
	public static final String STOREIDD ="please enter existing store id";
	public static final String NOTADDED = "Pizza not added";


}
