
package com.cg.pos.exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus
public class PizzaException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private HttpStatus status;

	public PizzaException(String errorMassage) {
		super(errorMassage);
	}

//	public PizzaException(String errorMessage, HttpStatus httpStatus) {
//		super(errorMessage);
//		status = httpStatus;
//	}
//
//	public HttpStatus getStatus() {
//		return status;
//	}

}
