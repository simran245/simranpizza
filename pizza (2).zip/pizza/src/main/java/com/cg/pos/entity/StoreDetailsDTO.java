package com.cg.pos.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "store")
public class StoreDetailsDTO implements Serializable{

	@Override
	public String toString() {
		return "StoreDetailsDTO [storeId=" + storeId + ", storeName=" + storename + ", storeAddress=" + storeAddress
				+ ", StoreContact=" + Storecontact + ", Ownername=" + Ownername + "]";
	}

	@Id
	@Column(name = "storeid")
	private int storeId;
	@Column(name = "storename")
	private String storename;
	@Column(name = "storeaddress")
	private String storeAddress;
	@Column(name = "storecontact")
	private String Storecontact;
	@Column(name = "ownername")
	private String Ownername;

	public StoreDetailsDTO() {

	}

	public int getStoreId() {
		return storeId;
	}

	public void setStoreId(int storeId) {
		this.storeId = storeId;
	}

	public int getId() {
		return storeId;
	}

	public StoreDetailsDTO(int id, String storeName, String storeAddress, String storeContact, String ownername) {

		this.storeId = id;
		this.storename = storeName;
		this.storeAddress = storeAddress;
		Storecontact = storeContact;
		Ownername = ownername;
	}

	public void setId(int id) {
		this.storeId = id;
	}

	public String getStoreName() {
		return storename;
	}

	public void setStoreName(String storeName) {
		this.storename = storeName;
	}

	public String getStoreAddress() {
		return storeAddress;
	}

	public void setStoreAddress(String storeAddress) {
		this.storeAddress = storeAddress;
	}

	public String getStoreContact() {
		return Storecontact;
	}

	public void setStoreContact(String storeContact) {
		Storecontact = storeContact;
	}

	public String getOwnername() {
		return Ownername;
	}

	public void setOwnername(String ownername) {
		Ownername = ownername;
	}

}
