package com.cg.pos.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.cg.pos.PizzaApplication;
import com.cg.pos.entity.PizzaDetailsDTO;
import com.cg.pos.entity.StoreDetailsDTO;
import com.cg.pos.exceptions.PizzaException;
import com.cg.pos.service.PizzaService;
import com.cg.pos.utility.ExceptionMessages;

/*
 * @Controller
 */
@RestController
@RequestMapping("/pizzaDatas")
public class UserControl {

	@Autowired
	private PizzaService service;

//   Logger logger=LoggerFactory.getLogger(PizzaApplication.class);
	public void setService(PizzaService service) {
		this.service = service;
	}

	/*
	 * Addition of pizza to database
	 */
	@RequestMapping(value = "/add/{storeId}", method = RequestMethod.POST, consumes = "application/json")

	public int addPizzaDetails(@RequestBody PizzaDetailsDTO pizzaDetailsDTO, @PathVariable("storeId") int storeId)
			throws PizzaException {
		int result;
		StoreDetailsDTO storeDetailsDTO = new StoreDetailsDTO();
		storeDetailsDTO.setId(storeId);
		result = service.add(pizzaDetailsDTO, storeDetailsDTO);
		if(result==0) {
			throw new PizzaException(ExceptionMessages.NOTADDED);
		}
		return result;
	}

	/*
	 * get list of all pizza
	 */
	@RequestMapping(value = "/getPizzaDetails", method = RequestMethod.GET, produces = "application/json")
	public List<PizzaDetailsDTO> viewPizza() throws PizzaException {

		 List<PizzaDetailsDTO> pizza=service.viewPizza();
		 if(pizza==null) {
			 throw new PizzaException(ExceptionMessages.NOTAVIALABLE);
		 }
		return pizza;

	}

	/*
	 * get list of all pizza by id
	 */
	@RequestMapping(value = "/{id}", method = RequestMethod.GET, produces = "application/json")
	public PizzaDetailsDTO getPizzaById(@PathVariable("id") Integer pizzaId) throws PizzaException {
//		logger.info(pizzaId+"");
		PizzaDetailsDTO pizzaDetailsDTO = null;
		pizzaDetailsDTO = service.retrive(pizzaId);
		if(pizzaDetailsDTO==null) {
			throw new PizzaException(ExceptionMessages.NOTAVIALABLE);
		}
		//		logger.info("LIST OF P IZZA");
		return pizzaDetailsDTO;

	}

//	@RequestMapping(value = "/viewstore{id}", method = RequestMethod.GET, produces = "application/json")
//	public PizzaDetailsDTO getStoreById(@PathVariable("id") Integer storeId) throws PizzaException {
//		PizzaDetailsDTO pizzaDetailsDTO = null;
//		pizzaDetailsDTO = service.getStoreList(storeId);
//		return pizzaDetailsDTO;
//	}

}
