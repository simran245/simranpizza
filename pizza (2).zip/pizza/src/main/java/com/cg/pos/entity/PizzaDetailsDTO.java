package com.cg.pos.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;

/**
 * 
 * @author Simran pizza DTO classs
 */
@Entity
@Table(name = "Pizza")
public class PizzaDetailsDTO implements Serializable{
	/**
	 * 
	 */
	@Id
	@Column(name = "Itemid")
	@GeneratedValue(strategy = GenerationType.AUTO, generator = "myseq")
	@SequenceGenerator(name = "myseq", sequenceName = "myseqq", initialValue = 101, allocationSize = 1)
	private int pizzaid;
	@Column(name = "Quantity")
	private int pizzaquantity;
	@Column(name = "price")
	private int pizzacost;

	@ManyToOne
	@JoinColumn(name = "storeid")
	private StoreDetailsDTO store;

	public PizzaDetailsDTO(int pizzaId, StoreDetailsDTO store, int pizzaQuantity, int pizzaCost, String pizzaName) {
		super();
		this.pizzaid = pizzaId;
		this.store = store;
		this.pizzaquantity = pizzaQuantity;
		this.pizzacost = pizzaCost;
		this.pizzaname = pizzaName;
	}

	public StoreDetailsDTO getStore() {
		return store;
	}

	public void setStore(StoreDetailsDTO store) {
		this.store = store;
	}

	@NotEmpty(message = "Please enter Pizzaname")
	@Column(name = "Pizzaname")
	private String pizzaname;

	public int getPizzaId() {
		return pizzaid;
	}

	public void setPizzaId(int pizzaId) {
		this.pizzaid = pizzaId;
	}

	public int getPizzaQuantity() {
		return pizzaquantity;
	}

	public void setPizzaQuantity(int pizzaQuantity) {
		this.pizzaquantity = pizzaQuantity;
	}

	public int getPizzaCost() {
		return pizzacost;
	}

	public void setPizzaCost(int pizzaCost) {
		this.pizzacost = pizzaCost;
	}

	public String getPizzaName() {
		return pizzaname;
	}

	public void setPizzaName(String pizzaName) {
		this.pizzaname = pizzaName;
	}

	@Override
	public String toString() {
		return "PizzaDetailsDTO [storeId=" + store + ", pizzaId=" + pizzaid + ", pizzaQuantity=" + pizzaquantity
				+ ", pizzaCost=" + pizzacost + ", pizzaName=" + pizzaname + "]";
	}

	public PizzaDetailsDTO() {

	}

}
